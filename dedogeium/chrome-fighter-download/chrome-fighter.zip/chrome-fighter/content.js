// Content script for Chrome Fighter extension

// Function to perform auto action
function performAutoAction(action, delay, settings) {
  setTimeout(() => {
    switch(action) {
      case 'attack':
        performAttacks(settings);
        break;
      case 'defend':
        console.log('Auto defending');
        const defendBtn = document.querySelector('.defend-button');
        if (defendBtn) defendBtn.click();
        break;
      case 'flee':
        console.log('Auto fleeing');
        const fleeBtn = document.querySelector('.flee-button');
        if (fleeBtn) fleeBtn.click();
        break;
      case 'none':
        // Do nothing
        break;
    }
  }, delay);
}

// Function to perform attacks based on settings
function performAttacks(settings) {
  const { attackType, attackCount, attackInterval } = settings;
  for (let i = 0; i < attackCount; i++) {
    setTimeout(() => {
      console.log(`Performing ${attackType} attack ${i + 1}`);
      let selector;
      switch(attackType) {
        case 'basic':
          selector = '.basic-attack-button';
          break;
        case 'special':
          selector = '.special-attack-button';
          break;
        case 'ultimate':
          selector = '.ultimate-attack-button';
          break;
      }
      const attackBtn = document.querySelector(selector);
      if (attackBtn) attackBtn.click();
    }, i * attackInterval);
  }
}

// Function to check for doge spawn
function checkForDogeSpawn() {
  // Replace with actual detection logic
  // Example: check for a specific element that appears when doge spawns
  const dogeElement = document.querySelector('.doge-spawned');
  if (dogeElement && !dogeElement.dataset.autoHandled) {
    dogeElement.dataset.autoHandled = 'true';
    chrome.storage.sync.get({
      autoEnabled: false,
      autoAction: 'attack',
      autoDelay: 1000,
      attackType: 'basic',
      attackCount: 1,
      attackInterval: 500
    }, function(settings) {
      if (settings.autoEnabled) {
        performAutoAction(settings.autoAction, settings.autoDelay, settings);
      }
    });
  }
}

// Monitor for changes in the DOM (for dynamic content)
const observer = new MutationObserver(checkForDogeSpawn);
observer.observe(document.body, { childList: true, subtree: true });

// Also check periodically
setInterval(checkForDogeSpawn, 1000);