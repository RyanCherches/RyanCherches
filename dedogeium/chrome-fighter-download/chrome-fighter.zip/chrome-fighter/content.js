if (!window.__screenFighterInitialized) {
  window.__screenFighterInitialized = true;

  const currentUrl = new URL(window.location.href);
  const isDedogeiumPage =
    currentUrl.hostname === "ryancherches.com" &&
    currentUrl.pathname.toLowerCase().startsWith("/dedogeium");
  const forceSpawnForTesting =
    currentUrl.searchParams.get("screen-fighter-test") === "1" ||
    currentUrl.searchParams.get("screen-fighter-spawn") === "1" ||
    currentUrl.hash.includes("screen-fighter-test");
  const scriptBuild = "2026-04-20-imgfix-2";

  const fighterWidth = 108;
  const startPosition = -fighterWidth - 28;
  const enemyTop = 200;
  const fightSpacing = 168;
  const attackDelayMs = 220;
  const meterFrameIntervalMs = 33;
  const spawnChance = 0.5;
  const spawnCooldownMs = 8 * 60 * 1000;
  const eliteHealthChance = 0.16;
  const baseDogeImage = "chill-doge.png";
  const fireDogeImage = "fire-doge.png";
  const level2EnemyImage = "level2-boss-doge.png";
  const level3EnemyImage = "level3-boss-doge.png";
  const level4EnemyImage = "level4-boss-doge.png";
  const level7EnemyImage = "level7-fire-boss-doge.png";
  const level8EnemyImage = "level8-fire-boss-doge.png";
  const defaultEnemyImage = "enemy.png";
  const defaultPlayerImage = "player.png";
  const pendingCurrencyKey = "pendingDedogeiumCurrency";
  const snapshotKey = "dedogeiumBattleSnapshot";
  const autoBattleSettingsKey = "dedogeiumAutoBattleSettings";
  const autoBattleOverrideKey = "screenFighterAutoBattleSettings";
  const disabledKey = "screenFighterDisabled";
  const battleModeKey = "screenFighterBattleMode";
  const lastSpawnAtKey = "screenFighterLastSpawnAt";
  const controlsCollapsedKey = "screenFighterControlsCollapsed";
  const defaultBattleMode = "auto";
  const healthStorageKeys = ["playerHP", "totalHP", "hpTotal", "total_hp", "hp"];
  const rarityBonuses = {
    Doge: {
      Common: { damage: 2, health: 50 },
      Uncommon: { damage: 5, health: 100 },
      Rare: { damage: 10, health: 150 },
      Epic: { damage: 20, health: 250 },
      Legendary: { damage: 40, health: 400 },
      Godly: { damage: 80, health: 600 }
    },
    "Fire Doge": {
      Common: { damage: 4, health: 100 },
      Uncommon: { damage: 8, health: 160 },
      Rare: { damage: 15, health: 240 },
      Epic: { damage: 30, health: 375 },
      Legendary: { damage: 60, health: 600 },
      Godly: { damage: 120, health: 900 }
    }
  };
  const manualActions = {
    damage: {
      label: "Damage",
      description: "Balanced hit with your full damage.",
      damageMultiplier: 1,
      healRatio: 0,
      selfDamageRatio: 0,
      defensePenaltyHits: 0,
      accuracyBonus: 0,
      ignoreDefenseRatio: 0,
      healFromDamageRatio: 0,
      staminaGain: 1
    },
    bulwark: {
      label: "More Health Less Damage",
      description: "Heal a little now, but hit softer.",
      damageMultiplier: 0.72,
      healRatio: 0.12,
      selfDamageRatio: 0,
      defensePenaltyHits: 0,
      accuracyBonus: 0.08,
      ignoreDefenseRatio: 0,
      healFromDamageRatio: 0,
      staminaGain: 1
    },
    fury: {
      label: "More Damage Less Health",
      description: "Hit harder and spend some of your own HP.",
      damageMultiplier: 1.42,
      healRatio: 0,
      selfDamageRatio: 0.08,
      defensePenaltyHits: 0,
      accuracyBonus: 0,
      ignoreDefenseRatio: 0.08,
      healFromDamageRatio: 0,
      staminaGain: 1
    },
    reckless: {
      label: "More Damage Less Defence",
      description: "Big damage, but your defence drops for 2 enemy hits.",
      damageMultiplier: 1.55,
      healRatio: 0,
      selfDamageRatio: 0,
      defensePenaltyHits: 2,
      accuracyBonus: 0,
      ignoreDefenseRatio: 0.22,
      healFromDamageRatio: 0,
      staminaGain: 1
    },
    precision: {
      label: "Precision Strike",
      description: "More reliable timing with a little defense pierce.",
      damageMultiplier: 0.9,
      healRatio: 0,
      selfDamageRatio: 0,
      defensePenaltyHits: 0,
      accuracyBonus: 0.22,
      ignoreDefenseRatio: 0.16,
      healFromDamageRatio: 0,
      staminaGain: 1
    },
    siphon: {
      label: "Siphon Bite",
      description: "Drain some health back from the damage you deal.",
      damageMultiplier: 0.92,
      healRatio: 0,
      selfDamageRatio: 0,
      defensePenaltyHits: 0,
      accuracyBonus: 0.05,
      ignoreDefenseRatio: 0,
      healFromDamageRatio: 0.38,
      staminaGain: 1
    },
    guardbreak: {
      label: "Guard Break",
      description: "Smash through defense to set up a finisher.",
      damageMultiplier: 1.16,
      healRatio: 0,
      selfDamageRatio: 0,
      defensePenaltyHits: 0,
      accuracyBonus: -0.02,
      ignoreDefenseRatio: 0.72,
      healFromDamageRatio: 0,
      staminaGain: 0.8
    },
    charge: {
      label: "Charge Up",
      description: "Hit softer now, but build a lot more stamina.",
      damageMultiplier: 0.68,
      healRatio: 0,
      selfDamageRatio: 0,
      defensePenaltyHits: 0,
      accuracyBonus: 0.06,
      ignoreDefenseRatio: 0,
      healFromDamageRatio: 0,
      staminaGain: 2
    }
  };

  let enemyPosition = startPosition;
  let movementAnimationId = 0;
  let meterAnimationId = 0;
  let meterPausedUntil = 0;
  let lastMeterFrameAt = 0;
  let isFighting = false;
  let battleFinished = false;
  let battleMode = defaultBattleMode;
  let spawnProfile = null;
  let playerStats = null;
  let enemyStats = null;
  let enemy = null;
  let player = null;
  let enemyBar = null;
  let playerBar = null;
  let playerMeter = null;
  let enemyMeter = null;
  let playerSide = null;
  let enemySide = null;
  let controlsPanel = null;
  let toggleButton = null;
  let modeButton = null;
  let settingsButton = null;
  let collapseButton = null;
  let encounterPanel = null;
  let actionPanel = null;
  let autoSettingsPanel = null;
  let pendingManualActionResolve = null;
  let controlsCollapsed = false;

  function isExtensionContextAvailable() {
    return Boolean(
      typeof chrome !== "undefined" &&
        chrome.runtime &&
        chrome.runtime.id &&
        typeof chrome.runtime.getURL === "function" &&
        chrome.storage &&
        chrome.storage.local
    );
  }

  function getAssetUrl(fileName) {
    if (!isExtensionContextAvailable()) {
      return null;
    }

    try {
      return chrome.runtime.getURL(fileName);
    } catch (error) {
      console.warn("Screen Fighter extension context unavailable while resolving asset:", fileName);
      return null;
    }
  }
  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
  const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
  const swordCursor =
    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'%3E%3Cg transform='rotate(-35 16 16)'%3E%3Crect x='14' y='3' width='4' height='15' rx='1' fill='%23dfe6ee'/%3E%3Crect x='13' y='2' width='6' height='3' rx='1' fill='%23f7fbff'/%3E%3Crect x='10' y='17' width='12' height='4' rx='1.5' fill='%23c9972f'/%3E%3Crect x='14' y='21' width='4' height='7' rx='1' fill='%235b3a1a'/%3E%3Ccircle cx='16' cy='28' r='3' fill='%23a06a2b'/%3E%3C/g%3E%3C/svg%3E\") 6 6, pointer";
  const wait = (ms) =>
    new Promise((resolve) => {
      window.setTimeout(resolve, ms);
    });
  const safeFinished = (animation) =>
    animation && animation.finished ? animation.finished.catch(() => undefined) : Promise.resolve();
  const storageGet = (keys) =>
    new Promise((resolve) => {
      if (!isExtensionContextAvailable()) {
        resolve({});
        return;
      }

      try {
        chrome.storage.local.get(keys, resolve);
      } catch (error) {
        console.warn("Screen Fighter storage get skipped because the extension context was invalidated.");
        resolve({});
      }
    });
  const storageSet = (values) =>
    new Promise((resolve) => {
      if (!isExtensionContextAvailable()) {
        resolve();
        return;
      }

      try {
        chrome.storage.local.set(values, resolve);
      } catch (error) {
        console.warn("Screen Fighter storage set skipped because the extension context was invalidated.");
        resolve();
      }
    });

  function injectBattleStyles() {
    if (document.getElementById("screen-fighter-battle-styles")) {
      return;
    }

    const style = document.createElement("style");
    style.id = "screen-fighter-battle-styles";
    style.textContent = `
      .sf-health-wrapper {
        position: fixed;
        width: 124px;
        height: 16px;
        padding: 2px;
        border-radius: 999px;
        border: 1px solid rgba(255, 255, 255, 0.82);
        background: rgba(10, 12, 16, 0.82);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.28);
        display: none;
        pointer-events: none;
        z-index: 1003;
        contain: layout style paint;
      }

      .sf-health-text {
        position: absolute;
        left: 50%;
        bottom: calc(100% + 6px);
        transform: translateX(-50%);
        padding: 4px 8px;
        border-radius: 999px;
        border: 1px solid rgba(255, 255, 255, 0.24);
        background: rgba(6, 8, 12, 0.82);
        backdrop-filter: blur(4px);
        font: 700 12px/1 Arial, sans-serif;
        color: #fff9cf;
        white-space: nowrap;
        text-shadow:
          0 1px 0 rgba(0, 0, 0, 0.55),
          0 0 10px rgba(0, 0, 0, 0.4);
      }

      .sf-health-fill {
        height: 100%;
        width: 100%;
        border-radius: 999px;
        transition: width 0.18s ease;
      }

      .sf-meter {
        position: fixed;
        width: 196px;
        display: none;
        pointer-events: none;
        z-index: 1003;
        contain: layout style paint;
      }

      .sf-meter-label {
        margin-bottom: 4px;
        font: 700 11px/1.2 Arial, sans-serif;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #ffffff;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
      }

      .sf-meter-info {
        margin-bottom: 6px;
        font: 700 10px/1.25 Arial, sans-serif;
        color: #ffe9a2;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.38);
      }

      .sf-meter-track {
        position: relative;
        height: 22px;
        border-radius: 999px;
        overflow: visible;
        border: 2px solid rgba(255, 255, 255, 0.82);
        background:
          linear-gradient(
            90deg,
            #ff2c34 0%,
            #ff2c34 16%,
            #f07a1d 16%,
            #f07a1d 31%,
            #ffe758 31%,
            #ffe758 44%,
            #6e8408 44%,
            #6e8408 56%,
            #ffe758 56%,
            #ffe758 69%,
            #f07a1d 69%,
            #f07a1d 84%,
            #ff2c34 84%,
            #ff2c34 100%
          );
        box-shadow:
          0 6px 14px rgba(0, 0, 0, 0.32),
          inset 0 2px 6px rgba(255, 255, 255, 0.24);
      }

      .sf-meter-center-line {
        position: absolute;
        left: 50%;
        top: -2px;
        bottom: -2px;
        width: 4px;
        transform: translateX(-50%);
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.5);
        box-shadow: 0 0 10px rgba(255, 255, 255, 0.38);
      }

      .sf-meter-pointer {
        position: absolute;
        left: 50%;
        top: -34px;
        transform: translateX(-50%);
        display: flex;
        flex-direction: column;
        align-items: center;
        transition: filter 0.12s ease;
      }

      .sf-meter-pointer-hit {
        filter: brightness(1.12) drop-shadow(0 0 14px rgba(255, 231, 88, 0.9));
      }

      .sf-pointer-knob {
        width: 26px;
        height: 18px;
        border-radius: 999px;
        background: radial-gradient(circle at 35% 30%, #fff8c1 0%, #f1d980 55%, #e6c861 100%);
        box-shadow:
          inset 0 -2px 3px rgba(0, 0, 0, 0.12),
          0 2px 8px rgba(0, 0, 0, 0.25);
      }

      .sf-pointer-tip {
        width: 0;
        height: 0;
        margin-top: -1px;
        border-left: 16px solid transparent;
        border-right: 16px solid transparent;
        border-top: 28px solid #d93d63;
        filter: drop-shadow(0 3px 6px rgba(0, 0, 0, 0.24));
      }

      .sf-impact-burst {
        position: fixed;
        width: 52px;
        height: 52px;
        margin-left: -26px;
        margin-top: -26px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(255, 244, 154, 0.95) 0%, rgba(255, 173, 56, 0.6) 50%, rgba(255, 77, 77, 0) 72%);
        pointer-events: none;
        z-index: 1005;
        animation: sf-impact-burst 0.45s ease-out forwards;
        contain: layout style paint;
      }

      .sf-floating-damage {
        position: fixed;
        font: 700 18px/1 Arial, sans-serif;
        color: #fff9cf;
        text-shadow:
          0 1px 0 rgba(0, 0, 0, 0.5),
          0 0 12px rgba(255, 192, 72, 0.8);
        pointer-events: none;
        z-index: 1006;
        animation: sf-floating-damage 0.75s ease-out forwards;
        contain: layout style paint;
      }

      .sf-floating-damage-heal {
        color: #d2ffd3;
        text-shadow:
          0 1px 0 rgba(0, 0, 0, 0.5),
          0 0 12px rgba(84, 206, 98, 0.82);
      }

      .sf-floating-damage-recoil {
        color: #ffc7bc;
        text-shadow:
          0 1px 0 rgba(0, 0, 0, 0.5),
          0 0 12px rgba(255, 97, 66, 0.8);
      }

      .sf-battle-banner {
        position: fixed;
        left: 50%;
        top: 120px;
        transform: translateX(-50%);
        padding: 10px 18px;
        border-radius: 999px;
        background: rgba(14, 16, 22, 0.88);
        color: #fff6cf;
        font: 700 16px/1 Arial, sans-serif;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        box-shadow: 0 10px 24px rgba(0, 0, 0, 0.32);
        z-index: 1007;
        pointer-events: none;
      }

      .sf-controls {
        position: fixed;
        right: 16px;
        bottom: 16px;
        display: flex;
        align-items: flex-end;
        gap: 8px;
        z-index: 1008;
      }

      .sf-controls-stack {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      .sf-controls-collapsed .sf-controls-stack {
        display: none;
      }

      .sf-control-button {
        padding: 10px 14px;
        border: 1px solid rgba(255, 255, 255, 0.25);
        border-radius: 999px;
        background: rgba(10, 12, 18, 0.84);
        color: #fff9cf;
        font: 700 12px/1 Arial, sans-serif;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.26);
        backdrop-filter: blur(6px);
        cursor: pointer;
      }

      .sf-control-button:hover {
        transform: translateY(-1px);
      }

      .sf-collapse-button {
        width: 38px;
        height: 38px;
        padding: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        line-height: 1;
      }

      .sf-toggle-button-off {
        background: rgba(78, 18, 18, 0.9);
        color: #ffe7c0;
      }

      .sf-panel {
        position: fixed;
        left: 50%;
        transform: translateX(-50%);
        min-width: min(92vw, 430px);
        max-width: min(92vw, 430px);
        padding: 16px;
        border-radius: 22px;
        border: 1px solid rgba(255, 255, 255, 0.24);
        background:
          linear-gradient(180deg, rgba(24, 18, 16, 0.96) 0%, rgba(11, 10, 12, 0.94) 100%);
        box-shadow:
          0 18px 42px rgba(0, 0, 0, 0.42),
          inset 0 1px 0 rgba(255, 255, 255, 0.08);
        color: #fff4cb;
        display: none;
        gap: 12px;
        z-index: 1009;
      }

      .sf-panel-encounter {
        top: 94px;
      }

      .sf-panel-action {
        bottom: 108px;
      }

      .sf-panel-settings {
        top: 96px;
      }

      .sf-panel-title {
        font: 700 18px/1.2 Arial, sans-serif;
      }

      .sf-panel-copy {
        font: 600 13px/1.45 Arial, sans-serif;
        color: #f6dcac;
      }

      .sf-panel-note {
        font: 700 12px/1.35 Arial, sans-serif;
        color: #ffe98f;
      }

      .sf-choice-row {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
      }

      .sf-choice-button {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
        padding: 12px;
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.06);
        color: #fff6cf;
        cursor: pointer;
        text-align: left;
      }

      .sf-choice-button:hover {
        transform: translateY(-1px);
        border-color: rgba(255, 231, 135, 0.55);
        background: rgba(255, 255, 255, 0.1);
      }

      .sf-choice-button-primary {
        background: linear-gradient(180deg, rgba(242, 181, 66, 0.92) 0%, rgba(203, 116, 23, 0.92) 100%);
        color: #261206;
      }

      .sf-choice-title {
        font: 700 13px/1.2 Arial, sans-serif;
      }

      .sf-choice-copy {
        font: 600 12px/1.4 Arial, sans-serif;
        opacity: 0.92;
      }

      .sf-settings-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }

      .sf-settings-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
        font: 700 12px/1.35 Arial, sans-serif;
        color: #ffeec2;
      }

      .sf-settings-field-wide {
        grid-column: 1 / -1;
      }

      .sf-settings-select,
      .sf-settings-range {
        width: 100%;
      }

      .sf-settings-select {
        padding: 10px 12px;
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.08);
        color: #fff7d6;
        font: 700 12px/1.2 Arial, sans-serif;
      }

      .sf-settings-select option {
        color: #101215;
      }

      .sf-settings-value {
        font: 700 11px/1.2 Arial, sans-serif;
        color: #ffe98f;
      }

      .sf-settings-actions {
        display: flex;
        justify-content: flex-end;
      }

      .sf-settings-status {
        font: 700 11px/1.3 Arial, sans-serif;
        color: #c8ffcb;
      }

      @media (max-width: 640px) {
        .sf-choice-row {
          grid-template-columns: 1fr;
        }

        .sf-panel {
          width: min(92vw, 430px);
        }

        .sf-settings-grid {
          grid-template-columns: 1fr;
        }
      }

      @keyframes sf-impact-burst {
        0% { opacity: 0.95; transform: scale(0.35); }
        100% { opacity: 0; transform: scale(1.8); }
      }

      @keyframes sf-floating-damage {
        0% { opacity: 0; transform: translateY(10px) scale(0.85); }
        18% { opacity: 1; transform: translateY(0px) scale(1); }
        100% { opacity: 0; transform: translateY(-34px) scale(1.08); }
      }
    `;

    document.head.appendChild(style);
  }

  async function applyBundledImage(img, fileName) {
    const assetUrl = getAssetUrl(fileName);
    if (!assetUrl) {
      return;
    }
    return new Promise((resolve) => {
      const cleanup = () => {
        img.removeEventListener("load", handleLoad);
        img.removeEventListener("error", handleError);
      };
      const handleLoad = () => {
        cleanup();
        resolve();
      };
      const handleError = () => {
        cleanup();
        console.error("Screen Fighter could not load bundled image:", fileName, assetUrl);
        resolve();
      };

      img.addEventListener("load", handleLoad, { once: true });
      img.addEventListener("error", handleError, { once: true });
      img.src = assetUrl;
    });
  }

  async function applyBundledImageWithFallback(img, primaryFileName, fallbackFileName) {
    const primaryUrl = getAssetUrl(primaryFileName);
    const fallbackUrl = getAssetUrl(fallbackFileName);
    if (!primaryUrl && !fallbackUrl) {
      return;
    }

    return new Promise((resolve) => {
      let onPrimary = true;
      const cleanup = () => {
        img.removeEventListener("load", handleLoad);
        img.removeEventListener("error", handleError);
      };
      const handleLoad = () => {
        cleanup();
        resolve();
      };
      const handleError = () => {
        if (onPrimary) {
          if (!fallbackUrl) {
            cleanup();
            resolve();
            return;
          }
          console.error(
            "Screen Fighter could not load bundled image:",
            primaryFileName,
            primaryUrl,
            "Falling back to",
            fallbackFileName
          );
          onPrimary = false;
          img.src = fallbackUrl;
          return;
        }

        cleanup();
        console.error("Screen Fighter could not load fallback image:", fallbackFileName, fallbackUrl);
        resolve();
      };

      img.addEventListener("load", handleLoad, { once: true });
      img.addEventListener("error", handleError);
      img.src = primaryUrl || fallbackUrl;
    });
  }

  function createFighter(id, zIndex, face) {
    const fighter = document.createElement("img");
    fighter.id = id;
    fighter.alt = id;
    fighter.style.position = "fixed";
    fighter.style.top = enemyTop + "px";
    fighter.style.width = fighterWidth + "px";
    fighter.style.height = fighterWidth + "px";
    fighter.style.objectFit = "contain";
    fighter.style.zIndex = String(zIndex);
    fighter.style.transform = `scaleX(${face})`;
    fighter.style.filter = "drop-shadow(0 14px 16px rgba(0, 0, 0, 0.24))";
    fighter.style.transition = "left 0.35s ease, top 0.25s ease, opacity 0.35s ease";
    fighter.style.willChange = "transform, opacity";
    fighter.dataset.face = String(face);
    if (id === "enemy") {
      fighter.style.cursor = swordCursor;
    }
    return fighter;
  }

  function createHealthBar(id, fillColor) {
    const wrapper = document.createElement("div");
    const text = document.createElement("div");
    const fill = document.createElement("div");

    wrapper.id = id;
    wrapper.className = "sf-health-wrapper";
    text.className = "sf-health-text";
    text.textContent = "HP 0 / 0";
    fill.className = "sf-health-fill";
    fill.style.background = fillColor;
    wrapper.appendChild(text);
    wrapper.appendChild(fill);
    document.body.appendChild(wrapper);

    return { wrapper, text, fill };
  }

  function createCombatMeter(id, label) {
    const wrapper = document.createElement("div");
    const meterLabel = document.createElement("div");
    const meterInfo = document.createElement("div");
    const track = document.createElement("div");
    const centerLine = document.createElement("div");
    const pointer = document.createElement("div");
    const knob = document.createElement("div");
    const tip = document.createElement("div");

    wrapper.id = id;
    wrapper.className = "sf-meter";
    meterLabel.className = "sf-meter-label";
    meterLabel.textContent = label;
    meterInfo.className = "sf-meter-info";
    meterInfo.textContent = "";
    track.className = "sf-meter-track";
    centerLine.className = "sf-meter-center-line";
    pointer.className = "sf-meter-pointer";
    knob.className = "sf-pointer-knob";
    tip.className = "sf-pointer-tip";
    pointer.style.willChange = "left, filter";

    pointer.appendChild(knob);
    pointer.appendChild(tip);
    track.appendChild(centerLine);
    track.appendChild(pointer);
    wrapper.appendChild(meterLabel);
    wrapper.appendChild(meterInfo);
    wrapper.appendChild(track);
    document.body.appendChild(wrapper);

    return {
      wrapper,
      label: meterLabel,
      info: meterInfo,
      track,
      pointer,
      position: 0.5,
      profile: null
    };
  }

  function createControlsPanel() {
    const wrapper = document.createElement("div");
    const stack = document.createElement("div");
    const toggle = document.createElement("button");
    const mode = document.createElement("button");
    const settings = document.createElement("button");
    const collapse = document.createElement("button");

    wrapper.className = "sf-controls";
    stack.className = "sf-controls-stack";
    toggle.type = "button";
    toggle.className = "sf-control-button";
    mode.type = "button";
    mode.className = "sf-control-button";
    settings.type = "button";
    settings.className = "sf-control-button";
    collapse.type = "button";
    collapse.className = "sf-control-button sf-collapse-button";

    stack.appendChild(settings);
    stack.appendChild(mode);
    stack.appendChild(toggle);
    wrapper.appendChild(stack);
    wrapper.appendChild(collapse);
    document.body.appendChild(wrapper);

    return { wrapper, stack, toggle, mode, settings, collapse };
  }

  function createEncounterPanel() {
    const wrapper = document.createElement("div");
    const title = document.createElement("div");
    const copy = document.createElement("div");
    const note = document.createElement("div");
    const buttons = document.createElement("div");
    const fight = document.createElement("button");
    const pass = document.createElement("button");

    wrapper.className = "sf-panel sf-panel-encounter";
    title.className = "sf-panel-title";
    copy.className = "sf-panel-copy";
    note.className = "sf-panel-note";
    buttons.className = "sf-choice-row";
    fight.type = "button";
    pass.type = "button";
    fight.className = "sf-choice-button sf-choice-button-primary";
    pass.className = "sf-choice-button";
    fight.innerHTML =
      '<span class="sf-choice-title">Fight</span><span class="sf-choice-copy">Jump into the battle.</span>';
    pass.innerHTML =
      '<span class="sf-choice-title">Let It Pass</span><span class="sf-choice-copy">Skip this doge and keep browsing.</span>';

    fight.addEventListener("click", () => {
      void startFight();
    });
    pass.addEventListener("click", () => {
      void letDogePass();
    });

    buttons.appendChild(fight);
    buttons.appendChild(pass);
    wrapper.appendChild(title);
    wrapper.appendChild(copy);
    wrapper.appendChild(note);
    wrapper.appendChild(buttons);
    document.body.appendChild(wrapper);

    return { wrapper, title, copy, note };
  }

  function createManualActionButton(key, config) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "sf-choice-button";
    button.dataset.action = key;
    button.innerHTML =
      `<span class="sf-choice-title">${config.label}</span>` +
      `<span class="sf-choice-copy">${config.description}</span>`;

    button.addEventListener("click", () => {
      if (!pendingManualActionResolve) {
        return;
      }

      const resolve = pendingManualActionResolve;
      pendingManualActionResolve = null;
      hideActionPanel();
      resolve(key);
    });

    return button;
  }

  function createActionPanel() {
    const wrapper = document.createElement("div");
    const title = document.createElement("div");
    const copy = document.createElement("div");
    const note = document.createElement("div");
    const buttons = document.createElement("div");

    wrapper.className = "sf-panel sf-panel-action";
    title.className = "sf-panel-title";
    copy.className = "sf-panel-copy";
    note.className = "sf-panel-note";
    buttons.className = "sf-choice-row";

    Object.entries(manualActions).forEach(([key, config]) => {
      buttons.appendChild(createManualActionButton(key, config));
    });

    wrapper.appendChild(title);
    wrapper.appendChild(copy);
    wrapper.appendChild(note);
    wrapper.appendChild(buttons);
    document.body.appendChild(wrapper);

    return { wrapper, title, copy, note };
  }

  function createAutoSettingsPanel() {
    const wrapper = document.createElement("div");
    const title = document.createElement("div");
    const copy = document.createElement("div");
    const grid = document.createElement("div");
    const status = document.createElement("div");
    const actions = document.createElement("div");
    const resetButton = document.createElement("button");

    wrapper.className = "sf-panel sf-panel-settings";
    title.className = "sf-panel-title";
    copy.className = "sf-panel-copy";
    grid.className = "sf-settings-grid";
    status.className = "sf-settings-status";
    actions.className = "sf-settings-actions";
    resetButton.type = "button";
    resetButton.className = "sf-choice-button";
    resetButton.innerHTML =
      '<span class="sf-choice-title">Reset Auto Settings</span><span class="sf-choice-copy">Go back to the default setup.</span>';

    const fields = [
      {
        key: "preferredAction",
        label: "Preferred Auto Move",
        type: "select"
      },
      {
        key: "lowHealthAction",
        label: "Low-Health Move",
        type: "select"
      },
      {
        key: "finisherAction",
        label: "Finisher Move",
        type: "select"
      },
      {
        key: "lowHealthThreshold",
        label: "Use Low-Health Move Below",
        type: "range",
        min: 10,
        max: 80,
        step: 5,
        wide: true,
        suffix: "%"
      },
      {
        key: "finisherThreshold",
        label: "Use Finisher Below Enemy HP",
        type: "range",
        min: 5,
        max: 50,
        step: 5,
        wide: true,
        suffix: "%"
      }
    ];

    const controls = {};

    fields.forEach((field) => {
      const label = document.createElement("label");
      const caption = document.createElement("span");
      let control;

      label.className = "sf-settings-field" + (field.wide ? " sf-settings-field-wide" : "");
      caption.textContent = field.label;

      if (field.type === "select") {
        control = document.createElement("select");
        control.className = "sf-settings-select";
        Object.entries(manualActions).forEach(([key, config]) => {
          const option = document.createElement("option");
          option.value = key;
          option.textContent = config.label;
          control.appendChild(option);
        });
      } else {
        control = document.createElement("input");
        control.type = "range";
        control.className = "sf-settings-range";
        control.min = String(field.min);
        control.max = String(field.max);
        control.step = String(field.step);
      }

      control.dataset.key = field.key;
      label.appendChild(caption);
      label.appendChild(control);

      if (field.type === "range") {
        const value = document.createElement("div");
        value.className = "sf-settings-value";
        value.dataset.valueFor = field.key;
        label.appendChild(value);
        controls[`${field.key}Value`] = value;
      }

      controls[field.key] = control;
      grid.appendChild(label);
    });

    actions.appendChild(resetButton);
    title.textContent = "Auto Battle Settings";
    copy.textContent = "Customize which moves auto mode should use in different situations.";
    status.textContent = "Saved.";

    wrapper.appendChild(title);
    wrapper.appendChild(copy);
    wrapper.appendChild(grid);
    wrapper.appendChild(status);
    wrapper.appendChild(actions);
    document.body.appendChild(wrapper);

    return {
      wrapper,
      title,
      copy,
      status,
      resetButton,
      controls
    };
  }

  function updateToggleButton(disabled) {
    if (!toggleButton) {
      return;
    }

    toggleButton.textContent = disabled ? "Enable Doges" : "Disable Doges";
    toggleButton.classList.toggle("sf-toggle-button-off", disabled);
  }

  function updateModeButton(mode) {
    if (!modeButton) {
      return;
    }

    modeButton.textContent = mode === "manual" ? "Battle: Manual" : "Battle: Auto";
  }

  function updateSettingsButton() {
    if (!settingsButton) {
      return;
    }

    settingsButton.textContent = "Auto Settings";
  }

  function updateCollapseButton() {
    if (!collapseButton || !controlsPanel) {
      return;
    }

    controlsPanel.wrapper.classList.toggle("sf-controls-collapsed", controlsCollapsed);
    collapseButton.textContent = controlsCollapsed ? "<" : ">";
    collapseButton.setAttribute(
      "aria-label",
      controlsCollapsed ? "Show doge controls" : "Hide doge controls"
    );
    collapseButton.title = controlsCollapsed ? "Show controls" : "Hide controls";
  }

  function readJsonStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function getItemType(item) {
    return item && item.name === "Fire Doge" ? "Fire Doge" : "Doge";
  }

  function getItemBonus(item) {
    const bonusGroup = rarityBonuses[getItemType(item)] || {};
    return bonusGroup[item && item.rarity] || { damage: 0, health: 0 };
  }

  function getBaseHealthFromStorage() {
    for (const key of healthStorageKeys) {
      const rawValue = localStorage.getItem(key);
      if (rawValue !== null && rawValue.trim() !== "" && !Number.isNaN(Number(rawValue))) {
        return Number(rawValue);
      }
    }

    return 0;
  }

  function normalizeStats(stats) {
    const maxHealth = clamp(Math.round(Number(stats && stats.maxHealth) || 50), 10, 5000);
    const damage = clamp(Math.round(Number(stats && stats.damage) || 2), 1, 1000);
    const derivedDefense = Math.round(maxHealth * 0.08 + damage * 0.35);
    const defense = clamp(
      Math.round(
        Number.isFinite(Number(stats && stats.defense)) ? Number(stats.defense) : derivedDefense
      ),
      0,
      600
    );

    return {
      ...(stats || {}),
      maxHealth,
      damage,
      defense
    };
  }

  function getDefaultAutoBattleSettings() {
    return {
      preferredAction: "damage",
      lowHealthAction: "bulwark",
      lowHealthThreshold: 35,
      finisherAction: "guardbreak",
      finisherThreshold: 20
    };
  }

  function isKnownActionKey(actionKey) {
    return Object.prototype.hasOwnProperty.call(manualActions, actionKey);
  }

  function normalizeAutoBattleSettings(settings) {
    const defaults = getDefaultAutoBattleSettings();
    const normalized = {
      preferredAction: isKnownActionKey(settings && settings.preferredAction)
        ? settings.preferredAction
        : defaults.preferredAction,
      lowHealthAction: isKnownActionKey(settings && settings.lowHealthAction)
        ? settings.lowHealthAction
        : defaults.lowHealthAction,
      lowHealthThreshold: clamp(
        Math.round(
          Number.isFinite(Number(settings && settings.lowHealthThreshold))
            ? Number(settings.lowHealthThreshold)
            : defaults.lowHealthThreshold
        ),
        10,
        80
      ),
      finisherAction: isKnownActionKey(settings && settings.finisherAction)
        ? settings.finisherAction
        : defaults.finisherAction,
      finisherThreshold: clamp(
        Math.round(
          Number.isFinite(Number(settings && settings.finisherThreshold))
            ? Number(settings.finisherThreshold)
            : defaults.finisherThreshold
        ),
        5,
        50
      )
    };

    return normalized;
  }

  async function loadAutoBattleSettingsOverride() {
    const stored = await storageGet([autoBattleOverrideKey]);
    if (!stored || !stored[autoBattleOverrideKey]) {
      return null;
    }

    return normalizeAutoBattleSettings(stored[autoBattleOverrideKey]);
  }

  async function saveAutoBattleSettingsOverride(settings) {
    const normalized = normalizeAutoBattleSettings(settings);
    await storageSet({ [autoBattleOverrideKey]: normalized });

    if (isDedogeiumPage) {
      localStorage.setItem(autoBattleSettingsKey, JSON.stringify(normalized));
      await syncDedogeiumSnapshot();
    }

    return normalized;
  }

  function buildStatsFromDedogeiumStorage() {
    const inventory = readJsonStorage("inventory", []);
    const equippedItems = readJsonStorage("equippedItems", []);
    const sourceItems = equippedItems.length > 0 ? equippedItems : inventory.slice(0, 5);
    let totalDamage = 0;
    let totalHealth = getBaseHealthFromStorage();

    sourceItems.forEach((item) => {
      const bonus = getItemBonus(item);
      totalDamage += bonus.damage;
      totalHealth += bonus.health;
    });

    return normalizeStats({
      maxHealth: totalHealth || 50,
      damage: totalDamage || 2,
      autoBattleSettings: normalizeAutoBattleSettings(
        readJsonStorage(autoBattleSettingsKey, getDefaultAutoBattleSettings())
      ),
      inventory,
      equippedItems: sourceItems
    });
  }

  async function syncDedogeiumSnapshot() {
    if (!isDedogeiumPage) {
      return null;
    }

    const snapshot = buildStatsFromDedogeiumStorage();
    snapshot.currency = parseInt(localStorage.getItem("currency") || "0", 10);
    snapshot.updatedAt = Date.now();
    await storageSet({ [snapshotKey]: snapshot });
    return snapshot;
  }

  async function flushPendingCurrencyToDedogeium() {
    if (!isDedogeiumPage) {
      return;
    }

    const stored = await storageGet([pendingCurrencyKey]);
    const pendingReward = Number(stored[pendingCurrencyKey] || 0);

    if (pendingReward <= 0) {
      return;
    }

    const currentCurrency = parseInt(localStorage.getItem("currency") || "0", 10);
    localStorage.setItem("currency", String(currentCurrency + pendingReward));
    await storageSet({ [pendingCurrencyKey]: 0 });
  }

  async function getPlayerStats() {
    const overrideSettings = await loadAutoBattleSettingsOverride();

    if (isDedogeiumPage) {
      const snapshot = await syncDedogeiumSnapshot();
      return normalizeStats({
        ...snapshot,
        autoBattleSettings: normalizeAutoBattleSettings(
          overrideSettings || (snapshot && snapshot.autoBattleSettings)
        )
      });
    }

    const stored = await storageGet([snapshotKey]);
    const snapshot = stored[snapshotKey];

    if (snapshot && typeof snapshot.maxHealth === "number" && typeof snapshot.damage === "number") {
      return normalizeStats({
        ...snapshot,
        autoBattleSettings: normalizeAutoBattleSettings(
          overrideSettings || snapshot.autoBattleSettings
        )
      });
    }

    return normalizeStats({
      maxHealth: 50,
      damage: 2,
      defense: 5,
      autoBattleSettings: normalizeAutoBattleSettings(overrideSettings),
      inventory: [],
      equippedItems: []
    });
  }

  function buildSpawnProfile() {
    const isElite = Math.random() < eliteHealthChance;
    const standardEnemies = [
      { name: "Level 2 Boss Doge", imageFile: level2EnemyImage },
      { name: "Level 3 Boss Doge", imageFile: level3EnemyImage },
      { name: "Level 4 Boss Doge", imageFile: level4EnemyImage }
    ];
    const lateEnemies = [
      { name: "Level 5 Second Cousin Doge", imageFile: baseDogeImage },
      { name: "Level 6 Fire Doge", imageFile: fireDogeImage },
      { name: "Level 7 Fire Boss Doge", imageFile: level7EnemyImage },
      { name: "Level 8 Fire Final Boss Doge", imageFile: level8EnemyImage }
    ];
    const pool = isElite ? lateEnemies : standardEnemies;
    const selectedEnemy = pool[randomInt(0, pool.length - 1)];

    return {
      isElite,
      name: selectedEnemy.name,
      imageFile: selectedEnemy.imageFile
    };
  }

  function getPlayerImageFile() {
    return baseDogeImage;
  }

  function getEnemyStats(currentPlayerStats) {
    const isElite = Boolean(spawnProfile && spawnProfile.isElite);
    const healthMin = isElite
      ? Math.max(14, Math.round(currentPlayerStats.maxHealth * 1.05))
      : Math.max(10, Math.round(currentPlayerStats.maxHealth * 0.78));
    const healthMax = isElite
      ? Math.max(healthMin + 2, Math.round(currentPlayerStats.maxHealth * 1.24))
      : Math.max(healthMin + 2, Math.round(currentPlayerStats.maxHealth * 0.99));
    const damageMin = isElite
      ? Math.max(1, Math.round(currentPlayerStats.damage * 0.92))
      : Math.max(1, Math.round(currentPlayerStats.damage * 0.72));
    const damageMax = isElite
      ? Math.max(damageMin + 1, Math.round(currentPlayerStats.damage * 1.15))
      : Math.max(damageMin + 1, Math.round(currentPlayerStats.damage * 0.96));
    const defenseMin = isElite
      ? Math.max(0, Math.round(currentPlayerStats.defense * 0.9))
      : Math.max(0, Math.round(currentPlayerStats.defense * 0.7));
    const defenseMax = isElite
      ? Math.max(defenseMin + 1, Math.round(currentPlayerStats.defense * 1.05))
      : Math.max(defenseMin + 1, Math.round(currentPlayerStats.defense * 0.92));

    const stats = normalizeStats({
      maxHealth: randomInt(healthMin, healthMax),
      damage: randomInt(damageMin, damageMax),
      defense: randomInt(defenseMin, defenseMax),
      isElite,
      name: spawnProfile ? spawnProfile.name : "Chill Doge",
      imageFile: spawnProfile ? spawnProfile.imageFile : baseDogeImage
    });

    stats.reward = Math.round(
      stats.maxHealth + stats.damage * 7 + stats.defense * 4 + (isElite ? 42 : 16)
    );

    return stats;
  }

  function setFighterLeft(fighter, left) {
    fighter.style.left = left + "px";
  }

  function setHealthBarPosition(bar, left) {
    bar.wrapper.style.left = left + "px";
    bar.wrapper.style.top = enemyTop - 26 + "px";
  }

  function setMeterPosition(meter, left) {
    meter.wrapper.style.left = left - 36 + "px";
    meter.wrapper.style.top = enemyTop + fighterWidth + 16 + "px";
  }

  function updateHealthBar(bar, currentHealth, maxHealth) {
    const ratio = clamp(currentHealth / maxHealth, 0, 1);
    bar.fill.style.width = ratio * 100 + "%";
    bar.text.textContent = `HP ${Math.max(0, Math.round(currentHealth))} / ${Math.max(
      0,
      Math.round(maxHealth)
    )}`;
  }

  function renderMeterPointer(meter) {
    meter.pointer.style.left = meter.position * 100 + "%";
  }

  function computeMeterPosition(meter, now) {
    const seconds = now / 1000;
    const profile = meter.profile;
    const raw =
      0.5 +
      Math.sin(seconds * profile.speed + profile.phase) * profile.swing +
      Math.sin(seconds * profile.speed * 2.3 + profile.phase * 0.65) * profile.jitter;
    const focused = 0.5 + (raw - 0.5) * profile.focus;
    return clamp(focused, 0.05, 0.95);
  }

  function animateMeters(now) {
    if (!isFighting || battleFinished) {
      meterAnimationId = 0;
      return;
    }

    if (now - lastMeterFrameAt < meterFrameIntervalMs) {
      meterAnimationId = requestAnimationFrame(animateMeters);
      return;
    }

    lastMeterFrameAt = now;

    if (now >= meterPausedUntil) {
      playerSide.meter.position = computeMeterPosition(playerSide.meter, now);
      enemySide.meter.position = computeMeterPosition(enemySide.meter, now);
      renderMeterPointer(playerSide.meter);
      renderMeterPointer(enemySide.meter);
    }

    meterAnimationId = requestAnimationFrame(animateMeters);
  }

  function ensureMeterAnimation() {
    if (!meterAnimationId) {
      lastMeterFrameAt = 0;
      meterAnimationId = requestAnimationFrame(animateMeters);
    }
  }

  function getStaminaBonus(side) {
    if (!side || side.key !== "player") {
      return 1;
    }

    return 1 + Math.min(side.stamina || 0, 8) * 0.07;
  }

  function getEffectiveDefense(side) {
    if (!side || !side.stats) {
      return 0;
    }

    const vulnerabilityScale = side.vulnerableHits > 0 ? 0.62 : 1;
    return clamp(Math.round(side.stats.defense * vulnerabilityScale), 0, 600);
  }

  function updateSideUi(side) {
    if (!side || !side.stats) {
      return;
    }

    updateHealthBar(side.healthBar, side.health, side.stats.maxHealth);

    const defenseLabel = `ATK ${side.stats.damage} • DEF ${getEffectiveDefense(side)}`;

    if (side.key === "player") {
      const staminaPercent = Math.round((getStaminaBonus(side) - 1) * 100);
      const dangerLabel = side.vulnerableHits > 0 ? " • DEF DOWN" : "";
      side.meter.info.textContent = `${defenseLabel} • STAMINA +${staminaPercent}%${dangerLabel}`;
      side.meter.label.textContent = battleMode === "manual" ? "Player Turn" : "Player Timing";
    } else {
      side.meter.info.textContent = defenseLabel;
      side.meter.label.textContent = side.stats.isElite ? "Fire Doge Timing" : "Enemy Timing";
    }
  }

  function getMeterResult(side) {
    const assistance = side.key === "player" ? 0.72 : 1.16;
    const adjustedPosition = clamp(0.5 + (side.meter.position - 0.5) * assistance, 0.03, 0.97);
    const distance = Math.abs(adjustedPosition - 0.5);
    const normalized = clamp(1 - distance / 0.5, 0, 1);
    let multiplier = 0.28 + Math.pow(normalized, 1.7) * 1.65;

    if (distance < 0.04) {
      multiplier += 0.32;
    } else if (distance < 0.1) {
      multiplier += 0.14;
    }

    multiplier *= side.key === "player" ? 1.08 : 0.92;

    let quality = "Weak";
    if (distance < 0.03) {
      quality = "Perfect";
    } else if (distance < 0.08) {
      quality = "Great";
    } else if (distance < 0.17) {
      quality = "Good";
    } else if (distance > 0.34) {
      quality = "Miss";
      multiplier = 0.16;
    }

    return {
      position: adjustedPosition,
      multiplier: clamp(multiplier, 0.16, 2.3),
      quality
    };
  }

  function showBattleBanner(text) {
    const banner = document.createElement("div");
    banner.className = "sf-battle-banner";
    banner.textContent = text;
    document.body.appendChild(banner);

    window.setTimeout(() => {
      banner.animate(
        [
          { opacity: 1, transform: "translateX(-50%) translateY(0px)" },
          { opacity: 0, transform: "translateX(-50%) translateY(-12px)" }
        ],
        { duration: 450, easing: "ease-out", fill: "forwards" }
      );

      window.setTimeout(() => banner.remove(), 460);
    }, 550);
  }

  function createImpactBurst(x, y) {
    const burst = document.createElement("div");
    burst.className = "sf-impact-burst";
    burst.style.left = x + "px";
    burst.style.top = y + "px";
    document.body.appendChild(burst);
    window.setTimeout(() => burst.remove(), 470);
  }

  function createFloatingText(x, y, text, variant) {
    const element = document.createElement("div");
    element.className = "sf-floating-damage";
    if (variant === "heal") {
      element.classList.add("sf-floating-damage-heal");
    }
    if (variant === "recoil") {
      element.classList.add("sf-floating-damage-recoil");
    }
    element.style.left = x + "px";
    element.style.top = y + "px";
    element.textContent = text;
    document.body.appendChild(element);
    window.setTimeout(() => element.remove(), 760);
  }

  function getFighterCenter(fighter) {
    const rect = fighter.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    };
  }

  async function playAttackAnimation(attackerSide, targetSide, quality) {
    const attackerFace = Number(attackerSide.fighter.dataset.face);
    const targetFace = Number(targetSide.fighter.dataset.face);
    const direction = attackerSide.key === "player" ? 1 : -1;
    const accent =
      quality === "Perfect"
        ? "drop-shadow(0 0 18px rgba(255, 242, 148, 0.88))"
        : "drop-shadow(0 0 10px rgba(255, 137, 64, 0.66))";

    attackerSide.meter.pointer.classList.add("sf-meter-pointer-hit");
    attackerSide.meter.track.animate(
      [
        { boxShadow: "0 6px 14px rgba(0, 0, 0, 0.32), inset 0 2px 6px rgba(255, 255, 255, 0.24)" },
        { boxShadow: "0 0 18px rgba(255, 236, 135, 0.86), 0 6px 14px rgba(0, 0, 0, 0.32), inset 0 2px 6px rgba(255, 255, 255, 0.24)" },
        { boxShadow: "0 6px 14px rgba(0, 0, 0, 0.32), inset 0 2px 6px rgba(255, 255, 255, 0.24)" }
      ],
      { duration: 220, easing: "ease-out" }
    );

    const attackerAnimation = attackerSide.fighter.animate(
      [
        { transform: `translateX(0px) translateY(0px) scaleX(${attackerFace}) scale(1)`, filter: "drop-shadow(0 14px 16px rgba(0, 0, 0, 0.24))" },
        { transform: `translateX(${direction * 34}px) translateY(-12px) scaleX(${attackerFace}) scale(1.12)`, filter: accent },
        { transform: `translateX(0px) translateY(0px) scaleX(${attackerFace}) scale(1)`, filter: "drop-shadow(0 14px 16px rgba(0, 0, 0, 0.24))" }
      ],
      { duration: 300, easing: "cubic-bezier(.2,.85,.22,1)" }
    );

    const targetAnimation = targetSide.fighter.animate(
      [
        { transform: `translateX(0px) scaleX(${targetFace}) scale(1)`, filter: "drop-shadow(0 14px 16px rgba(0, 0, 0, 0.24))" },
        { transform: `translateX(${direction * 16}px) scaleX(${targetFace}) scale(0.92)`, filter: "drop-shadow(0 0 18px rgba(255, 115, 87, 0.78))" },
        { transform: `translateX(0px) scaleX(${targetFace}) scale(1)`, filter: "drop-shadow(0 14px 16px rgba(0, 0, 0, 0.24))" }
      ],
      { duration: 310, easing: "ease-out" }
    );

    const center = getFighterCenter(targetSide.fighter);
    createImpactBurst(center.x, center.y);
    targetSide.healthBar.wrapper.animate(
      [{ transform: "scale(1)" }, { transform: "scale(1.06)" }, { transform: "scale(1)" }],
      { duration: 230, easing: "ease-out" }
    );

    await Promise.all([safeFinished(attackerAnimation), safeFinished(targetAnimation)]);
    attackerSide.meter.pointer.classList.remove("sf-meter-pointer-hit");
  }

  async function fadeOutScene(elements) {
    const visibleElements = elements.filter((element) => element && element.isConnected);
    if (visibleElements.length === 0) {
      return;
    }

    const animations = visibleElements.map((element) => {
      const face = element.dataset ? element.dataset.face : null;
      const startTransform = face ? `scaleX(${face}) scale(1)` : "scale(1)";
      const endTransform = face ? `scaleX(${face}) scale(0.72) translateY(18px)` : "scale(0.72) translateY(12px)";

      return safeFinished(
        element.animate(
          [{ opacity: 1, transform: startTransform }, { opacity: 0, transform: endTransform }],
          { duration: 420, easing: "ease-in", fill: "forwards" }
        )
      );
    });

    await Promise.all(animations);
    visibleElements.forEach((element) => element.remove());
  }

  async function awardCurrency(amount) {
    if (isDedogeiumPage) {
      const currentCurrency = parseInt(localStorage.getItem("currency") || "0", 10);
      localStorage.setItem("currency", String(currentCurrency + amount));
      await syncDedogeiumSnapshot();
      return;
    }

    const stored = await storageGet([pendingCurrencyKey]);
    const pendingReward = Number(stored[pendingCurrencyKey] || 0);
    await storageSet({ [pendingCurrencyKey]: pendingReward + amount });
  }

  function hideEncounterPanel() {
    if (encounterPanel) {
      encounterPanel.wrapper.style.display = "none";
    }
  }

  function refreshEncounterPanel() {
    if (!encounterPanel || !spawnProfile) {
      return;
    }

    encounterPanel.title.textContent = spawnProfile.isElite ? "Fire Doge Encounter" : "Doge Encounter";
    encounterPanel.copy.textContent = spawnProfile.isElite
      ? "This doge has a small chance to spawn with more HP than your doge."
      : "A Dedogeium-style doge wandered onto the page.";
    encounterPanel.note.textContent =
      battleMode === "manual"
        ? "Manual mode: pick one move every time your doge attacks."
        : "Auto mode: your doge fights on its own while stamina ramps up.";
  }

  function showEncounterPanel() {
    if (!encounterPanel || isFighting || battleFinished) {
      return;
    }

    refreshEncounterPanel();
    encounterPanel.wrapper.style.display = "grid";
  }

  function hideActionPanel() {
    if (actionPanel) {
      actionPanel.wrapper.style.display = "none";
    }
  }

  function hideAutoSettingsPanel() {
    if (autoSettingsPanel) {
      autoSettingsPanel.wrapper.style.display = "none";
    }
  }

  function updateAutoSettingsRangeLabels() {
    if (!autoSettingsPanel) {
      return;
    }

    const { controls } = autoSettingsPanel;
    if (controls.lowHealthThresholdValue) {
      controls.lowHealthThresholdValue.textContent = `${controls.lowHealthThreshold.value}% player HP`;
    }
    if (controls.finisherThresholdValue) {
      controls.finisherThresholdValue.textContent = `${controls.finisherThreshold.value}% enemy HP`;
    }
  }

  function applyAutoSettingsToPanel(settings) {
    if (!autoSettingsPanel) {
      return;
    }

    const normalized = normalizeAutoBattleSettings(settings);
    const { controls } = autoSettingsPanel;
    controls.preferredAction.value = normalized.preferredAction;
    controls.lowHealthAction.value = normalized.lowHealthAction;
    controls.finisherAction.value = normalized.finisherAction;
    controls.lowHealthThreshold.value = String(normalized.lowHealthThreshold);
    controls.finisherThreshold.value = String(normalized.finisherThreshold);
    updateAutoSettingsRangeLabels();
  }

  function readAutoSettingsFromPanel() {
    const { controls } = autoSettingsPanel;
    return normalizeAutoBattleSettings({
      preferredAction: controls.preferredAction.value,
      lowHealthAction: controls.lowHealthAction.value,
      finisherAction: controls.finisherAction.value,
      lowHealthThreshold: Number(controls.lowHealthThreshold.value),
      finisherThreshold: Number(controls.finisherThreshold.value)
    });
  }

  async function saveAutoSettingsFromPanel(statusText) {
    if (!autoSettingsPanel) {
      return;
    }

    const normalized = await saveAutoBattleSettingsOverride(readAutoSettingsFromPanel());
    applyAutoSettingsToPanel(normalized);

    if (playerSide && playerSide.stats) {
      playerSide.stats.autoBattleSettings = normalized;
      updateSideUi(playerSide);
    }

    autoSettingsPanel.status.textContent = statusText || "Saved.";
  }

  async function showAutoSettingsPanel() {
    if (!autoSettingsPanel) {
      return;
    }

    hideActionPanel();
    const settings =
      (playerSide && playerSide.stats && playerSide.stats.autoBattleSettings) ||
      (await loadAutoBattleSettingsOverride()) ||
      getDefaultAutoBattleSettings();
    applyAutoSettingsToPanel(settings);
    autoSettingsPanel.status.textContent = "Saved.";
    autoSettingsPanel.wrapper.style.display = "grid";
  }

  function updateActionPanel() {
    if (!actionPanel || !playerSide || !playerSide.stats) {
      return;
    }

    const staminaPercent = Math.round((getStaminaBonus(playerSide) - 1) * 100);
    actionPanel.title.textContent = "Choose Your Move";
    actionPanel.copy.textContent =
      "Manual fighting is on. Pick how you want this attack to work.";
    actionPanel.note.textContent = `Current stamina bonus: +${staminaPercent}% damage`;
  }

  function waitForManualAction() {
    updateActionPanel();
    actionPanel.wrapper.style.display = "grid";

    return new Promise((resolve) => {
      pendingManualActionResolve = resolve;
    });
  }

  function cancelPendingManualAction() {
    hideActionPanel();
    if (!pendingManualActionResolve) {
      return;
    }

    const resolve = pendingManualActionResolve;
    pendingManualActionResolve = null;
    resolve("damage");
  }

  function removeOffscreenEnemy() {
    cancelAnimationFrame(movementAnimationId);
    movementAnimationId = 0;
    if (meterAnimationId) {
      cancelAnimationFrame(meterAnimationId);
      meterAnimationId = 0;
    }

    cancelPendingManualAction();
    hideEncounterPanel();
    hideAutoSettingsPanel();

    [enemy, player, enemyBar && enemyBar.wrapper, playerBar && playerBar.wrapper, enemyMeter && enemyMeter.wrapper, playerMeter && playerMeter.wrapper]
      .filter(Boolean)
      .forEach((element) => {
        if (element.isConnected) {
          element.remove();
        }
      });
  }

  function maybePromptEncounter(force) {
    if (isFighting || battleFinished || !enemy) {
      return;
    }

    const encounterLeft = clamp(Math.round(window.innerWidth * 0.28), 84, window.innerWidth - 180);
    if (!force && enemyPosition < encounterLeft) {
      return;
    }

    cancelAnimationFrame(movementAnimationId);
    movementAnimationId = 0;
    showEncounterPanel();
  }

  function runEnemy() {
    enemyPosition += 4;
    setFighterLeft(enemy, enemyPosition);

    if (!isFighting) {
      const encounterLeft = clamp(Math.round(window.innerWidth * 0.28), 84, window.innerWidth - 180);
      if (enemyPosition >= encounterLeft && encounterPanel.wrapper.style.display !== "grid") {
        maybePromptEncounter(true);
        return;
      }
    }

    if (enemyPosition < window.innerWidth - fighterWidth && !isFighting) {
      movementAnimationId = requestAnimationFrame(runEnemy);
    } else if (!isFighting) {
      removeOffscreenEnemy();
    }
  }

  function initializeScene() {
    spawnProfile = buildSpawnProfile();
    battleFinished = false;
    enemyPosition = startPosition;

    enemy = createFighter("enemy", 999, -1);
    document.body.appendChild(enemy);
    void applyBundledImageWithFallback(enemy, spawnProfile.imageFile, defaultEnemyImage);

    player = createFighter("player", 1000, 1);
    void applyBundledImageWithFallback(player, baseDogeImage, defaultPlayerImage);

    enemyBar = createHealthBar("enemyHpBar", "linear-gradient(90deg, #ff9f68, #ff3d00)");
    playerBar = createHealthBar("playerHpBar", "linear-gradient(90deg, #8ef79a, #1f9d48)");
    playerMeter = createCombatMeter("playerCombatMeter", "Player Timing");
    enemyMeter = createCombatMeter("enemyCombatMeter", "Enemy Timing");

    playerSide = {
      key: "player",
      fighter: player,
      healthBar: playerBar,
      meter: playerMeter,
      stats: null,
      health: 0,
      stamina: 0,
      vulnerableHits: 0
    };

    enemySide = {
      key: "enemy",
      fighter: enemy,
      healthBar: enemyBar,
      meter: enemyMeter,
      stats: null,
      health: 0,
      stamina: 0,
      vulnerableHits: 0
    };

    playerMeter.profile = {
      speed: 7.2,
      phase: Math.random() * Math.PI * 2,
      swing: 0.23,
      jitter: 0.045,
      focus: 0.74
    };

    enemyMeter.profile = {
      speed: 8.4,
      phase: Math.random() * Math.PI * 2,
      swing: 0.31,
      jitter: 0.075,
      focus: 1.02
    };

    setFighterLeft(enemy, enemyPosition);
    enemy.addEventListener("click", () => {
      maybePromptEncounter(true);
    });

    runEnemy();
  }

  function getActionConfig(actionKey) {
    return manualActions[actionKey] || manualActions.damage;
  }

  function selectAutoAction(playerStats, playerHealth, enemyStats, enemyHealth) {
    const settings = normalizeAutoBattleSettings(
      playerStats && playerStats.autoBattleSettings
    );
    const playerHealthRatio =
      playerStats && playerStats.maxHealth > 0 ? playerHealth / playerStats.maxHealth : 1;
    const enemyHealthRatio =
      enemyStats && enemyStats.maxHealth > 0 ? enemyHealth / enemyStats.maxHealth : 1;

    if (playerHealthRatio <= settings.lowHealthThreshold / 100) {
      return settings.lowHealthAction;
    }

    if (enemyHealthRatio <= settings.finisherThreshold / 100) {
      return settings.finisherAction;
    }

    if (
      settings.preferredAction === "bulwark" &&
      enemyStats &&
      enemyHealth <= Math.max(6, enemyStats.maxHealth * 0.18)
    ) {
      return "damage";
    }

    return settings.preferredAction;
  }

  async function resolveAttack(attackerSide, targetSide, actionKey) {
    meterPausedUntil = performance.now() + 170;

    const result = getMeterResult(attackerSide);
    attackerSide.meter.position = result.position;
    renderMeterPointer(attackerSide.meter);

    const action = attackerSide.key === "player" ? getActionConfig(actionKey) : null;
    const attackMultiplier = clamp(
      result.multiplier + (action && Number.isFinite(action.accuracyBonus) ? action.accuracyBonus : 0),
      0.16,
      2.6
    );
    const staminaMultiplier = attackerSide.key === "player" ? getStaminaBonus(attackerSide) : 1;
    const rawDamage = Math.max(
      1,
      Math.round(
        attackerSide.stats.damage *
          attackMultiplier *
          staminaMultiplier *
          (action ? action.damageMultiplier : 1)
      )
    );
    const defenseReduction = Math.round(
      getEffectiveDefense(targetSide) *
        0.38 *
        (1 - (action && Number.isFinite(action.ignoreDefenseRatio) ? action.ignoreDefenseRatio : 0))
    );
    const damage = Math.max(1, rawDamage - defenseReduction);

    let healed = 0;
    let recoil = 0;

    if (action && action.healRatio > 0) {
      const directHeal = Math.max(2, Math.round(attackerSide.stats.maxHealth * action.healRatio));
      healed += directHeal;
      attackerSide.health = Math.min(attackerSide.stats.maxHealth, attackerSide.health + directHeal);
    }

    if (action && action.selfDamageRatio > 0) {
      recoil = Math.max(2, Math.round(attackerSide.stats.maxHealth * action.selfDamageRatio));
      attackerSide.health = Math.max(1, attackerSide.health - recoil);
    }

    if (action && action.healFromDamageRatio > 0) {
      const siphonHeal = Math.max(2, Math.round(damage * action.healFromDamageRatio));
      healed += siphonHeal;
      attackerSide.health = Math.min(attackerSide.stats.maxHealth, attackerSide.health + siphonHeal);
    }

    if (action && action.defensePenaltyHits > 0) {
      attackerSide.vulnerableHits = Math.max(attackerSide.vulnerableHits, action.defensePenaltyHits);
    }

    targetSide.health = Math.max(0, targetSide.health - damage);

    if (attackerSide.key === "player") {
      const staminaGain =
        action && Number.isFinite(action.staminaGain) ? action.staminaGain : 1;
      attackerSide.stamina = clamp((attackerSide.stamina || 0) + staminaGain, 0, 8);
    }

    if (attackerSide.key === "enemy" && targetSide.key === "player" && targetSide.vulnerableHits > 0) {
      targetSide.vulnerableHits = Math.max(0, targetSide.vulnerableHits - 1);
    }

    updateSideUi(attackerSide);
    updateSideUi(targetSide);

    await playAttackAnimation(attackerSide, targetSide, result.quality);

    const targetCenter = getFighterCenter(targetSide.fighter);
    createFloatingText(targetCenter.x - 26, targetCenter.y - 18, `${result.quality} -${damage}`);

    if (healed > 0) {
      const attackerCenter = getFighterCenter(attackerSide.fighter);
      createFloatingText(attackerCenter.x - 18, attackerCenter.y - 34, `+${healed} HP`, "heal");
    }

    if (recoil > 0) {
      const attackerCenter = getFighterCenter(attackerSide.fighter);
      createFloatingText(attackerCenter.x - 18, attackerCenter.y - 6, `-${recoil} HP`, "recoil");
    }

    await wait(attackDelayMs);
  }

  async function finishBattle(winner) {
    if (battleFinished) {
      return;
    }

    battleFinished = true;
    isFighting = false;

    if (meterAnimationId) {
      cancelAnimationFrame(meterAnimationId);
      meterAnimationId = 0;
    }

    cancelPendingManualAction();
    hideEncounterPanel();

    const reward = enemySide.stats.reward || enemySide.stats.maxHealth;
    const outcomeText =
      winner === "player"
        ? `Your doge won! Reward: ${reward} currency.`
        : `Your doge lost. Enemy HP: ${enemySide.stats.maxHealth}, your HP: ${playerSide.stats.maxHealth}.`;

    if (winner === "player") {
      await awardCurrency(reward);
      showBattleBanner("Victory");
    } else {
      showBattleBanner("Defeat");
    }

    await wait(380);
    await fadeOutScene([
      enemy,
      player,
      enemyBar.wrapper,
      playerBar.wrapper,
      enemyMeter.wrapper,
      playerMeter.wrapper
    ]);

    alert(outcomeText);
  }

  async function runBattleLoop() {
    let isPlayerTurn = true;

    while (isFighting && !battleFinished) {
      if (isPlayerTurn) {
        let actionKey = selectAutoAction(
          playerSide.stats,
          playerSide.health,
          enemySide.stats,
          enemySide.health
        );

        if (battleMode === "manual") {
          actionKey = await waitForManualAction();
          if (!isFighting || battleFinished) {
            return;
          }
        }

        await resolveAttack(playerSide, enemySide, actionKey);

        if (enemySide.health <= 0) {
          await finishBattle("player");
          return;
        }
      } else {
        hideActionPanel();
        await resolveAttack(enemySide, playerSide, "damage");

        if (playerSide.health <= 0) {
          await finishBattle("enemy");
          return;
        }
      }

      isPlayerTurn = !isPlayerTurn;
    }
  }

  async function letDogePass() {
    if (isFighting || battleFinished) {
      return;
    }

    hideEncounterPanel();
    showBattleBanner("You let the doge pass");
    await fadeOutScene([enemy]);
    removeOffscreenEnemy();
  }

  async function startFight() {
    if (isFighting || battleFinished) {
      return;
    }

    hideEncounterPanel();
    hideAutoSettingsPanel();

    playerStats = await getPlayerStats();
    enemyStats = getEnemyStats(playerStats);

    playerSide.stats = playerStats;
    playerSide.health = playerStats.maxHealth;
    playerSide.stamina = 0;
    playerSide.vulnerableHits = 0;

    enemySide.stats = enemyStats;
    enemySide.health = enemyStats.maxHealth;
    enemySide.stamina = 0;
    enemySide.vulnerableHits = 0;

    await Promise.all([
      applyBundledImageWithFallback(
        player,
        getPlayerImageFile(playerStats),
        defaultPlayerImage
      ),
      applyBundledImageWithFallback(
        enemy,
        enemyStats.imageFile || baseDogeImage,
        defaultEnemyImage
      )
    ]);

    isFighting = true;
    cancelAnimationFrame(movementAnimationId);
    movementAnimationId = 0;

    const playerFightLeft = 48;
    const enemyFightLeft = Math.max(
      playerFightLeft + fightSpacing,
      window.innerWidth - fighterWidth - 48
    );

    setFighterLeft(enemy, enemyFightLeft);
    setFighterLeft(player, playerFightLeft);

    if (!player.isConnected) {
      document.body.appendChild(player);
    }

    enemyBar.wrapper.style.display = "block";
    playerBar.wrapper.style.display = "block";
    enemyMeter.wrapper.style.display = "block";
    playerMeter.wrapper.style.display = "block";

    setHealthBarPosition(enemyBar, enemyFightLeft);
    setHealthBarPosition(playerBar, playerFightLeft);
    setMeterPosition(enemyMeter, enemyFightLeft);
    setMeterPosition(playerMeter, playerFightLeft);
    updateSideUi(enemySide);
    updateSideUi(playerSide);
    renderMeterPointer(enemyMeter);
    renderMeterPointer(playerMeter);

    showBattleBanner("Battle Start");
    await wait(260);

    const playerIntro = player.animate(
      [
        { transform: "translateX(-22px) translateY(10px) scaleX(1) scale(0.92)", opacity: 0.3 },
        { transform: "translateX(0px) translateY(0px) scaleX(1) scale(1)", opacity: 1 }
      ],
      { duration: 320, easing: "cubic-bezier(.16,.84,.24,1)", fill: "forwards" }
    );

    const enemyIntro = enemy.animate(
      [
        { transform: "translateX(24px) translateY(10px) scaleX(-1) scale(0.92)", opacity: 0.3 },
        { transform: "translateX(0px) translateY(0px) scaleX(-1) scale(1)", opacity: 1 }
      ],
      { duration: 320, easing: "cubic-bezier(.16,.84,.24,1)", fill: "forwards" }
    );

    await Promise.all([safeFinished(playerIntro), safeFinished(enemyIntro)]);
    ensureMeterAnimation();
    void runBattleLoop();
  }

  (async () => {
    console.info("Screen Fighter build loaded:", scriptBuild, {
      baseDogeImage,
      fireDogeImage,
      forceSpawnForTesting
    });
    injectBattleStyles();

    controlsPanel = createControlsPanel();
    toggleButton = controlsPanel.toggle;
    modeButton = controlsPanel.mode;
    settingsButton = controlsPanel.settings;
    collapseButton = controlsPanel.collapse;
    encounterPanel = createEncounterPanel();
    actionPanel = createActionPanel();
    autoSettingsPanel = createAutoSettingsPanel();

    await flushPendingCurrencyToDedogeium();
    await syncDedogeiumSnapshot();

    if (isDedogeiumPage) {
      window.addEventListener("screen-fighter-sync-snapshot", () => {
        void syncDedogeiumSnapshot();
      });
    }

    const stored = await storageGet([
      disabledKey,
      battleModeKey,
      lastSpawnAtKey,
      controlsCollapsedKey
    ]);
    const disabled = Boolean(stored[disabledKey]);
    battleMode = stored[battleModeKey] === "manual" ? "manual" : defaultBattleMode;
    const lastSpawnAt = Number(stored[lastSpawnAtKey] || 0);
    controlsCollapsed = Boolean(stored[controlsCollapsedKey]);
    const shouldSpawnThisVisit = Math.random() < spawnChance;
    const spawnOnCooldown = Date.now() - lastSpawnAt < spawnCooldownMs;

    updateToggleButton(disabled);
    updateModeButton(battleMode);
    updateSettingsButton();
    updateCollapseButton();

    toggleButton.addEventListener("click", async () => {
      const current = await storageGet([disabledKey]);
      const nextDisabled = !Boolean(current[disabledKey]);
      await storageSet({ [disabledKey]: nextDisabled });
      updateToggleButton(nextDisabled);
      window.location.reload();
    });

    modeButton.addEventListener("click", async () => {
      battleMode = battleMode === "manual" ? "auto" : "manual";
      await storageSet({ [battleModeKey]: battleMode });
      updateModeButton(battleMode);
      refreshEncounterPanel();
      updateSideUi(playerSide);
    });

    settingsButton.addEventListener("click", () => {
      if (autoSettingsPanel.wrapper.style.display === "grid") {
        hideAutoSettingsPanel();
        return;
      }

      void showAutoSettingsPanel();
    });

    autoSettingsPanel.resetButton.addEventListener("click", async () => {
      const defaults = getDefaultAutoBattleSettings();
      applyAutoSettingsToPanel(defaults);
      await saveAutoSettingsFromPanel("Reset to defaults.");
    });

    Object.values(autoSettingsPanel.controls).forEach((control) => {
      if (!(control instanceof HTMLElement)) {
        return;
      }

      const eventName = control.tagName === "INPUT" ? "input" : "change";
      control.addEventListener(eventName, () => {
        updateAutoSettingsRangeLabels();
        void saveAutoSettingsFromPanel("Saved auto settings.");
      });
    });

    collapseButton.addEventListener("click", async () => {
      controlsCollapsed = !controlsCollapsed;
      await storageSet({ [controlsCollapsedKey]: controlsCollapsed });
      updateCollapseButton();
    });

    if (forceSpawnForTesting) {
      initializeScene();
      return;
    }

    if (!disabled && !spawnOnCooldown && shouldSpawnThisVisit) {
      await storageSet({ [lastSpawnAtKey]: Date.now() });
      initializeScene();
    }
  })();
}
