// Load settings when page loads
document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.sync.get({
    autoEnabled: false,
    autoAction: 'attack',
    autoDelay: 1000,
    attackType: 'basic',
    attackCount: 1,
    attackInterval: 500
  }, function(items) {
    document.getElementById('autoEnabled').checked = items.autoEnabled;
    document.getElementById('autoAction').value = items.autoAction;
    document.getElementById('autoDelay').value = items.autoDelay;
    document.getElementById('attackType').value = items.attackType;
    document.getElementById('attackCount').value = items.attackCount;
    document.getElementById('attackInterval').value = items.attackInterval;
  });
});

// Save settings when form is submitted
document.getElementById('settingsForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const settings = {
    autoEnabled: document.getElementById('autoEnabled').checked,
    autoAction: document.getElementById('autoAction').value,
    autoDelay: parseInt(document.getElementById('autoDelay').value),
    attackType: document.getElementById('attackType').value,
    attackCount: parseInt(document.getElementById('attackCount').value),
    attackInterval: parseInt(document.getElementById('attackInterval').value)
  };
  chrome.storage.sync.set(settings, function() {
    alert('Settings saved!');
  });
});